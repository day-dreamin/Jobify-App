package com.example.pairpa
var reviews = listOf(
    listOf("Jake", "very nice", 5.0f),
    listOf("htet wai yan", "absolute shite", 1.0f)
) //do not make mutable. just set to another listOf. this will let update work
fun populateReviews(){
    //populate reviews
}
fun submitReview(stars: Float, text: String){
    //toast if failure
    populateReviews()
}
fun login(email: String, password: String): Boolean {
    //you must toast if there is fail. return true if login success
    //Toast.makeText(ctx, "text here", Toast.LENGTH_SHORT).show() - do this if error
    return true
}
fun signup(email: String, password: String): Boolean {
    //same deal as login
    return true
}