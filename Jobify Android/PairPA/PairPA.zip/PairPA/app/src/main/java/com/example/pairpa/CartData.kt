package com.example.pairpa

data class CartData(val itemName: String, val price: Int) {
    constructor() : this("", 100)
}