package com.example.pairpa

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.paint
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
@Composable
fun bg(code: @Composable () -> Unit){
    Box(
        modifier = Modifier.fillMaxSize()
            .paint(
                // Replace with your image id
                painterResource(id = R.drawable.bg),
                contentScale = ContentScale.FillBounds)

    )
    {
        code()
    }
}
@Composable
fun MainLayout() {
    LazyVerticalStaggeredGrid(
        columns = StaggeredGridCells.Fixed(2),
    ) {
        items(db.size) { id ->
            CardView(id)
        }
    }
}
@Preview
@Composable
fun PreviewList() {
    popupvisible =  remember { mutableStateOf(false) }
    clickedid =  remember { mutableStateOf(0) }
    MaterialTheme {
        Surface {
            MainLayout()
        }
    }
}