package com.example.pairpa

data class ReviewData(val dispName: String,
                      val content: String,
                      val rating: Float,
                      val added: Boolean) {
    constructor() : this("", "", 5.0f, false)
}