package com.example.pairpa

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.pairpa.getMenuBottomItems
import com.example.pairpa.navController

@Composable
fun generate(code: @Composable () -> Unit){
    Scaffold(
        modifier = Modifier.fillMaxWidth(),
        bottomBar = {
            BottomNavBar(
                navHostController = navController,
                items = getMenuBottomItems()
            )
        },
        content = {
            Box(modifier = Modifier.padding(it).fillMaxSize()){
                code()
            }
        }
    )
}
data class BottomNavigationItem(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val route: String,
)
@Composable
fun BottomNavBar(
    navHostController: NavHostController,
    items: List<BottomNavigationItem>
) {
    var selectedIndex by rememberSaveable { mutableStateOf(0) }
    val navBackStackEntry by navHostController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    NavigationBar{
        items.forEachIndexed { index, bottomNavigationItem ->
            NavigationBarItem(
                selected = currentDestination?.hierarchy?.any { it.route ==  bottomNavigationItem.route} == true,
                onClick = {
                    selectedIndex = index
                    navHostController.navigate(bottomNavigationItem.route) {
                        // Pop up to the start destination of the graph to
                        // avoid building up a large stack of destinations
                        // on the back stack as users select items
                        navHostController.graph.startDestinationRoute?.let { screen_route ->
                            popUpTo(screen_route) {
                                saveState = true
                            }
                        }
                        // Avoid multiple copies of the same destination when
                        // reselecting the same item
                        launchSingleTop = true
                        // Restore state when reselecting a previously selected item
                        restoreState = true
                    }
                },
                icon = {
                    Icon(
                        imageVector = if (index == selectedIndex) {
                            bottomNavigationItem.selectedIcon
                        } else bottomNavigationItem.unselectedIcon,
                        contentDescription = bottomNavigationItem.title)
                },
                label = { Text(text = bottomNavigationItem.title) },
                alwaysShowLabel = true
            )
        }
    }
}