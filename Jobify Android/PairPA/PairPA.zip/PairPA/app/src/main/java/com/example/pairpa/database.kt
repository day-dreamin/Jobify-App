package com.example.pairpa

val db = listOf(listOf("rupeeshirt",
    "Tops",
    "XXL",
    "40",
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et diam quis nulla efficitur fermentum. Aliquam purus augue, vehicula a est quis, eleifend sodales tellus. Nunc facilisis ligula et enim fringilla, tempus blandit velit placerat. Duis sodales tempus sem cursus aliquet. Proin lectus neque, faucibus at neque a, interdum iaculis eros. Nunc nec sem malesuada, interdum erat in, cursus lacus. Praesent gravida, dui at pellentesque laoreet, purus orci efficitur dolor, vel sollicitudin felis neque ut ligula. Aenean urna velit, porta ac enim in, blandit auctor nulla. Aenean in enim a lorem varius fringilla. Donec nec euismod massa. Ut ultrices, nisl at consequat laoreet, massa purus pretium magna, scelerisque consectetur lorem neque nec libero. Morbi ut justo pretium, rhoncus leo sit amet, blandit sapien. Mauris eleifend tempor justo at vehicula. ",
    R.drawable.image6))