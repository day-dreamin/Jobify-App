package com.example.pairpa

data class User(val cart: ArrayList<CartData>,
                val purchases: ArrayList<CartData>,
                val address: String,
                val number: String,)