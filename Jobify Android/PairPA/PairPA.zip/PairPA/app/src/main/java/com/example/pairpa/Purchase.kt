package com.example.pairpa

data class Purchase(val name: String, val price: Int, val date: String) {
    constructor() : this("", 0, "")
}