package com.example.pairpa

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.DefaultShadowColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat.startActivity
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.pairpa.ui.theme.PairPATheme
import com.gandiva.neumorphic.LightSource
import com.gandiva.neumorphic.neu
import com.gandiva.neumorphic.shape.Flat
import com.gandiva.neumorphic.shape.Pressed
import com.gandiva.neumorphic.shape.RoundedCorner


@SuppressLint("StaticFieldLeak")
lateinit var navController: NavHostController
lateinit var isDarkTheme: MutableState<Boolean>
@SuppressLint("StaticFieldLeak")
lateinit var ctx: Context
fun getMenuBottomItems() = mutableListOf<BottomNavigationItem>(
    BottomNavigationItem(
        title = "Products",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home,
        route = "main"
    ),
    BottomNavigationItem(
        title = "About",
        selectedIcon = Icons.Filled.Info,
        unselectedIcon = Icons.Outlined.Info,
        route = "info"
    ),
    BottomNavigationItem(
        title = "Reviews",
        selectedIcon = Icons.Filled.Send,
        unselectedIcon = Icons.Outlined.Send,
        route = "comment"
    ),
    BottomNavigationItem(
        title = "Login",
        selectedIcon = Icons.Filled.AccountCircle,
        unselectedIcon = Icons.Outlined.AccountCircle,
        route = "login"
    ),
)
lateinit var sharedPreference: SharedPreferences
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        ctx = getApplicationContext()
        super.onCreate(savedInstanceState)
        setContent {
            val dt = isSystemInDarkTheme()
            isDarkTheme = remember { mutableStateOf(dt) }
            PairPATheme(darkTheme = isDarkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Main()
                }
            }
        }
    }
}

@Composable
fun Main(){
    popupvisible =  remember { mutableStateOf(false) }
    clickedid =  remember { mutableStateOf(0) }
    navController = rememberNavController()
    NavHost(navController = navController, startDestination = "main") {
        composable("main") {
            generate{
                CollapsibleTb("Blossom Boutique",{
                    bg{
                        MainLayout()
                        DialogWithImage(
                            id = clickedid,
                            visible = popupvisible
                        )
                    }
                })
            }
        }
        composable("info"){
            generate {
                CollapsibleTb("About us", {
                    bg {
                        showabout()
                    }
                })
            }
        }
        composable("comment"){
            generate{
                CollapsibleTb("Reviews", {
                    bg {
                        ReviewLayout()
                    }
                })
            }
        }
        composable("login"){
            generate {
                CollapsibleTb("Login/Register", {
                    bg {
                        LoginBox()
                    }
                })
            }
        }
    }
}
@Preview
@Composable
fun PreviewCmp(){
    popupvisible =  remember { mutableStateOf(false) }
    clickedid =  remember { mutableStateOf(0) }
    navController = rememberNavController()
    generate{
        CollapsibleTb("le shoppe", {
            bg {
                ReviewLayout()
            }
        })
    }
}